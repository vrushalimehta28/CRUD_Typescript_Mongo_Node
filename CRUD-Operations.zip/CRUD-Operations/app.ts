let myname:string = 'hello';
console.log(myname);